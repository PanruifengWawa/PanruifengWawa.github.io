package com.service.impl;

import org.springframework.stereotype.Service;

import com.models.Result;
import com.service.CalculatorService;

@Service
public class CalculatorServiceImpl implements CalculatorService {

	@Override
	public Result add(int a, int b) {
		// TODO Auto-generated method stub
		Result result = new Result();
		result.setResult(a + b);
		return result;
	}

}
