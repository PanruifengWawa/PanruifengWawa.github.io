package com.service;

import com.models.Result;

public interface CalculatorService {
	Result add(int a, int b);
	
	Result getById(int id);

}
