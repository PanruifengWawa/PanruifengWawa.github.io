package com.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dao.ResultDao;
import com.models.Result;
import com.service.CalculatorService;

@Service
public class CalculatorServiceImpl implements CalculatorService {
	
	@Autowired
	ResultDao resultDao;

	@Override
	public Result add(int a, int b) {
		// TODO Auto-generated method stub
		Result result = new Result();
		result.setResult(a + b);
		return result;
	}

	@Override
	public Result getById(int id) {
		Long idLong = new Long(id);
		return resultDao.findById(idLong);
	}

}
