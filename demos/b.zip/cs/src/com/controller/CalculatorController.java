package com.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.models.Result;
import com.service.CalculatorService;

@Controller
@RequestMapping(value="/api")
public class CalculatorController {
	
	@Autowired
	CalculatorService calculatorService;
	
	@RequestMapping(value="add", method = {RequestMethod.GET,RequestMethod.POST})
	@ResponseBody
	public Result add(
			@RequestParam(name="a", required = true) Integer a,
			@RequestParam(name="b", required = true) Integer b
			) {
		
		return calculatorService.add(a, b);
		
	}
	
	@RequestMapping(value="getById", method = RequestMethod.GET)
	@ResponseBody
	public Result getById(
			@RequestParam(name="id", required = true) Integer id
			) {
		
		return calculatorService.getById(id);
	}
	
	

}
