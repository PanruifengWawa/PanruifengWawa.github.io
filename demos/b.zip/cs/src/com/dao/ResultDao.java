package com.dao;

import com.models.Result;

public interface ResultDao {
	Result findById(Long id);
}
