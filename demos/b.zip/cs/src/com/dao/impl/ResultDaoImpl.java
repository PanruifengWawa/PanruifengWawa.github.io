package com.dao.impl;

import org.springframework.stereotype.Repository;

import com.dao.BaseDao;
import com.dao.ResultDao;
import com.models.Result;

@Repository
public class ResultDaoImpl extends BaseDao<Result> implements ResultDao {

	@Override
	public Result findById(Long id) {
		// TODO Auto-generated method stub
		return get(id);
	}

}
